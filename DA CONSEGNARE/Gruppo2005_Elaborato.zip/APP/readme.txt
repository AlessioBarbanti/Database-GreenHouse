Tutorial Greenhouse_APP

L'applicazione prevede di aver installato nel pc Visual Studio 2019 con i pacchetti necessari ad avviare un server MSSQL.

1 - Aprire Visual Studio e premere le shortcut da tastiera ctrl+\ e successivamente ctrl+s, per accedere a "Esplora oggetti di SQL Server"

2 – Aprire i menù SQL Server > (localDB)\MSSQLLocalDB e premere con il tasto destro su “Database” e premere su “Pubblica Applicazione livello dati”

3 – Nella schermata che si è aperta, premere su sfoglia e inserire il file GreenhouseDatabase_DATI.dacpac presente nella cartella APP.
    In “Nome database:” inserire esattamente la stringa “GreenhouseDatabase” senza virgolette.

4 – Premere sul pulsante “Pubblica”, nella schermata che apparirà premere ”Sì” e attendere il completamento delle operazioni di creazione.

5 – Chiudere Visual Studio e avviare “GreenHouse_App.exe” e usufruire dell’applicazione.
