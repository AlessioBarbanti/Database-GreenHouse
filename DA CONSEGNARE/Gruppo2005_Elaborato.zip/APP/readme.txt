Tutorial Greenhouse_APP

L'applicazione prevede di aver installato nel pc Visual Studio 2019 con i pacchetti necessari ad avviare un server MSSQL.

1 - Aprire Visual Studio e premere su "Continua senza codice"

2 - Premere le shortcut da tastiera ctrl+\ e successivamente ctrl+s, per accedere a "Esplora oggetti di SQL Server"

3 – Aprire i menù SQL Server > (localDB)\MSSQLLocalDB e premere con il tasto destro su “Database” e premere su “Pubblica Applicazione livello dati”

4 – Nella schermata che si è aperta, premere su sfoglia e inserire il file GreenhouseDatabase_DATI.dacpac presente nella cartella APP.
    In “Nome database:” inserire esattamente la stringa “GreenhouseDatabase” senza virgolette.

5 – Premere sul pulsante “Pubblica”, nella schermata che apparirà premere ”Sì” e attendere il completamento delle operazioni di creazione.

6 – Chiudere Visual Studio e avviare “GreenHouse_App.exe” e usufruire dell’applicazione.

Dati consigliati per fare alcune prove:

- Form Ricercatore 
	ID Ricercatore: 1, 2, 6, 7, 8

- Form Gestore Struttura
	ID Struttura: 9, 10, 11

- Form Guida
	ID Guida: 
	- struttura 11: 2033, 12
	- struttura 10: 8, 2025
	- struttura 9: 2013, 11

- Form Supervisore
	ID Struttura: 9, 10, 11

- Form Gestore Esperimenti
	ID Gestore: 1014, 2025, 2034 
	ID Ricercatori Collaboratori: 1, 2, 6, 7, 8 